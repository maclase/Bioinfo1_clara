library(seqinr)
library(ade4)

bicho<-read.fasta("bicho.ffn")
tableGC<-data.frame(GC=sapply(bicho,GC),GC1=sapply(bicho,GC1),GC2=sapply(bicho,GC2),GC3=sapply(bicho,GC3))

mkdata <- function(seqs){
  # seqs es una lista de seqs como la que se genera con read.fasta()
  tab <- sapply(seqs, uco)  
  tab <- as.data.frame(tab)
  return( tab )
}

tab <- mkdata(bicho)

coa <- dudi.coa(tab, scan = FALSE, nf = 3)
facaa <- as.factor(aaa(translate(sapply(rownames(tab),s2c))))
scua <- wca(coa, facaa, scan = FALSE, nf = 3)

attributes(scua)
cor(scua$co,tableGC)

par(mfrow=c(1,2))

plot(scua$co[,1],scua$co[,2],pch=20,col="orange",xlab="Axis 1",ylab="Axis 2")
s.label(scua$li, add.plot = TRUE, clab = 0.75,boxes = FALSE)
abline(v=0,h=0)

plot(scua$co[,1],scua$co[,3],pch=20,col="orange",xlab="Axis 1",ylab="Axis 3")
s.label(scua$li, add.plot = TRUE, clab = 0.75,boxes = FALSE)
abline(v=0,h=0)

##################################
# Ahora vamos a ver qué pasa con alguna otra variable (para ver si los ejes 2 y 3 se correlacionan con algo)

# codonw bicho.ffn
# Después le digo que sí (ENTER) a lo que me pregunte.
# Elijo el menú 4, y dentro de él, las opciones gc, gc3 e hidropaticidad.
# Aprieto ENTER y luego R, para que corra el programa (hay que ir viendo qué opciones me da).
# Después ENTER otra vez, y q, para salir.
# Hago un head del archivo *out, y con read.table lo importo a R.
# Elimino la primera columna de out y guardo el resultado en out2.
# Recordemos que los tres ejes están en scua$co.
# Hagamos las correlaciones entre todas esas variables.
# Después creo otras variables, por ejemplo, largos. ¿Cómo se hace?
# Me fijo si la posición en el genoma tiene algo que ver con el GC, o con el largo.
# 
